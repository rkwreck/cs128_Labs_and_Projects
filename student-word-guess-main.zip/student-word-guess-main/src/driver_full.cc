//ADD include statements needed here

#include "word_guess_functions.hpp"

using namespace std;

// Write your driver for part 2 in this file. 

// Create and use your own functions in this file. 
// You do not want your main function over ~40 lines 
// of code to help with readability and reusability. 


// cout statements
// cout << "Select a mode, neutral or evil : ";
// cout << "Invalid. Please pick neutral, or evil : ";
string SelectMode() {}

int main() { string mode = SelectMode(); }
